package algorithms;

public interface SortAlgorithm {
    void sort(int[] arr);
    String name();
}

